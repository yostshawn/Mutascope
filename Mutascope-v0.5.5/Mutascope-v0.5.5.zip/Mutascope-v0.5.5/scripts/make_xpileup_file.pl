#! /usr/bin/perl -w

use warnings;
use strict;
use Getopt::Long;
use Cwd 'abs_path';
my $abs_path = abs_path(__FILE__);
my @tmp = split(/\//, $abs_path);
pop(@tmp);
$abs_path = join("/", @tmp);


my $bed;
my $fasta;
my $pdir;
my $samtools;
my $length=151;

GetOptions("bed=s" => \$bed,
						"fasta=s" => \$fasta,
						"pdir=s" => \$pdir,
						"samtools=s" => \$samtools,
						"length=i" => \$length);


my @rgs;
my %beds;
my %hash;

open(BED, $bed);
while(my $line = <BED>){
	chomp $line;
	next if($line =~ m/^track/);
	next if($line =~ m/^#/);
	next if($line =~ m/^>/);	
	my ($chr, $bstart, $bend, $name, $score, $strand, $pstart, $pend, @other) = split(/\t/, $line);
	$beds{$chr}{$bstart}{$bend} = $pstart."\t".$pend;
}
close(BED);

my $header = "";

open(SAM, $ARGV[0]);
while(my $line = <SAM>){
	chomp $line;
	if($line =~ m/^@/){
		$header .="$line\n";
	}
	
	if($line =~ m/^\@RG/){
		my @fields = split(/\t/, $line);
		my $rg = $fields[1];
		$rg =~ s/ID://;
		push(@rgs, $rg);
	}
	
	next if($line =~ m/^@/);
	
	my @info = split(/\t/, $line);
	my $flag = $info[1];
	my $tmp_rg;
	foreach (@info){
		if($_ =~ m/^RG:Z:/){
			$tmp_rg = $_;
			$tmp_rg =~ s/^RG:Z://;
		}
	}
	
	my $strand;
	if($flag == 0){
		$strand = "FOR";
	}else{
		$strand = "REV";
	}
	
	if(exists($hash{$tmp_rg}{$strand})){
		$hash{$tmp_rg}{$strand} .= "$line\n";
	}else{
		$hash{$tmp_rg}{$strand} = "$line\n";
	}
}
close(SAM);

my $tmp_counter = 1;

my $samp;

foreach my $rg (@rgs){
	if(exists($hash{$rg})){
		my ($sample, $read, $loc) = split(/_/, $rg);
		my ($chr, $pos) = split(/:/, $loc);
		my ($start, $stop) = split(/-/, $pos);
		my ($pstart, $pend) = split(/\t/, $beds{$chr}{$start}{$stop});
		
		foreach my $strand (keys %{$hash{$rg}}){
			
			open(TMP_OUT, ">$pdir/intermediate/tmp_sam_file_$sample.sam");
			print TMP_OUT "$header";
			print TMP_OUT "$hash{$rg}{$strand}";
			close(TMP_OUT);
			
			$samp = $sample;

			`$samtools view -Sbh $pdir/intermediate/tmp_sam_file_$sample.sam | $samtools mpileup -Bd 50000 -Q 0 -O -s -f $fasta - > $pdir/intermediate/tmp_pileup_file_$sample.txt`;
			
			`perl $abs_path/convert_pileup_to_xpileup.pl -primer_one_end $pstart -primer_two_start $pend -rg $rg -strand $strand -length $length -tmp_counter $tmp_counter $pdir/intermediate/tmp_pileup_file_$sample.txt`;
			
			$tmp_counter++;
			
		}

	}

}


`perl $abs_path/combine_xpileup_files.pl $pdir/intermediate/tmp_pileup_file_$samp\_* > $pdir/intermediate/$samp.xpileup`;

`rm $pdir/intermediate/tmp_pileup_file_$samp.txt`;
`rm $pdir/intermediate/tmp_pileup_file_$samp\_*`;
`rm $pdir/intermediate/tmp_sam_file_$samp.sam`;





