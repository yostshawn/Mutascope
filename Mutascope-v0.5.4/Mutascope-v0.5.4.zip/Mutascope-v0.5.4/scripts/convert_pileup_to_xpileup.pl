#! /usr/bin/perl -w

use strict;
use warnings;
use Getopt::Long;

my %SNPs = ('A',0,'T',0,'C',0,'G',0);

my $primer_one_end;
my $primer_two_start;
my $rg;
my $strand;
my $length=151;
my $tmp_counter=1;

GetOptions("primer_one_end=i" => \$primer_one_end,
						"primer_two_start=i" => \$primer_two_start,
						"rg=s" => \$rg,
						"strand=s" => \$strand,
						"tmp_counter=i" => \$tmp_counter,
						"length=i" => \$length);


open(IN, $ARGV[0]);
my $out = $ARGV[0];
$out =~ s/.txt//;
open(OUT, ">$out\_$tmp_counter.txt");


READLINE: while(my $line = <IN>){
	chomp $line;
	my ($chr, $pos, $ref, $cov, $read_bases, $base_quality, $map_quality, $read_position) = split(/\t/, $line);
	
	my %indels;
	my $indel_flag = 0;
	
	next READLINE if($pos < $primer_one_end or $pos > $primer_two_start);
	
#	$read_bases =~ tr/[a-z]/[A-Z]/;

	if($read_bases =~ m/[\$\^\+-]/){
		$read_bases =~ s/\^.//g; #removing the start of the read segement mark
		$read_bases =~ s/\$//g; #removing end of the read segment mark
		
		while($read_bases =~ m/[-]{1}(\d+)/) {
			$indel_flag = 1;
			my $indel_len = $1;
			my $count = 0;
			my $pat;
			while($read_bases =~ m/([-]{1}$indel_len.{$indel_len})/g){
				$pat = $1;
				$count++;
			}
			$indels{$pat} = $count; 
			$read_bases =~ s/$pat//gi; # remove indel info from read base field
		}
		
		while ($read_bases =~ m/[\+]{1}(\d+)/) {
			$indel_flag = 1;
			my $indel_len = $1;
			my $pat;
			my $count = 0;
			while($read_bases =~ m/[\+]{1}($indel_len.{$indel_len})/g){
				$pat = $1;
				$count++;
			}
			$indels{"+$pat"} = $count; 
			$read_bases =~ s/\+$pat//gi; # remove indel info from read base field
		}
		
	}

	my @bases = split(//, $read_bases);
	my @qv = split(//, $base_quality);
	my @mq = split(//, $map_quality);
	my @rp = split(/,/, $read_position);
	
	if($strand eq "REV"){
		for(my $i = 0; $i <= $#rp; $i++){
			$rp[$i] = $length + 1 - $rp[$i];
		}
	}
	
	$read_bases = join("", @bases);
	$base_quality = join("", @qv);
	$map_quality = join("", @mq);
	$read_position = join(",", @rp);
	
	print OUT "$chr\t$pos\t$ref\t$cov\t$rg $read_bases $base_quality $map_quality $read_position";
	if($indel_flag == 1){
		print OUT "\t$rg";
		foreach my $ind (keys %indels){
			print OUT "_$ind:$indels{$ind}";
		}
	}
	print OUT "\n";

}

close(IN);
