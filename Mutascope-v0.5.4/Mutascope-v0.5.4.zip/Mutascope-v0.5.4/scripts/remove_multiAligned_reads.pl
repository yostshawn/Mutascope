#! /usr/bin/perl -w

use warnings;
use strict;

my @reads;
my $prev_rname = "tmp";

open(SAM, $ARGV[0]);
while(my $line = <SAM>){
	chomp $line;
	print "$line\n" if($line =~ m/^@/);
	next if($line =~ m/^@/);
	my ($rname, @other) = split(/\t/, $line);
	if($prev_rname eq "tmp"){
		$prev_rname = $rname;
		push(@reads, $line);
	}else{
		if($rname eq $prev_rname){
			push(@reads, $line);
		}else{
			if($#reads == 0){
				$prev_rname = $rname;
				print "$reads[0]\n";
				@reads = ();
				push(@reads, $line);
			}else{
				$prev_rname = $rname;
				my $best_align = "tmp";
				my $best_as = 0;
				foreach my $ln (@reads){
					my (@tmps) = split(/\t/, $ln);
					my $as_tmp;
					foreach (@tmps){
						$as_tmp = $_ if($_ =~ m/^AS:i:/);
					}
					my ($tmp1, $tmp2, $as_score) = split(/:/, $as_tmp);
					if($as_score > $best_as){
						$best_as = $as_score;
						$best_align = $ln;
					}
				}
#				print "$best_align\n";
				@reads = ();
				push(@reads, $line);
			}
		}
	}
}

if($#reads == 0){
	print "$reads[0]\n";
}else{
	my $best_align = "tmp";
	my $best_as = 0;
	foreach my $ln (@reads){
		my (@tmps) = split(/\t/, $ln);
		my $as_tmp;
		foreach (@tmps){
			$as_tmp = $_ if($_ =~ m/^AS:i:/);
		}
		my ($tmp1, $tmp2, $as_score) = split(/:/, $as_tmp);
		if($as_score > $best_as){
			$best_as = $as_score;
			$best_align = $ln;
		}
	}
#	print "$best_align\n";
}
