#!/bin/sh

#INSTALL script

chmod 775 Mutascope.pl
chmod 775 scripts/faToTwoBit
chmod 775 scripts/twoBitToFa
chmod 775 test_scripts.sh

